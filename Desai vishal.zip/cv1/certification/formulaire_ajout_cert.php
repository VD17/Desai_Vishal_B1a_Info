<?php include("../inc/header.inc.php");?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title> Ajouter vos certifications </title>
  <link rel="stylesheet" href="wing.">
  <link rel="styleshee" href="style.css">
</head>
<body>
  <h1> Formulaire d'ajout d'un certificat </h1>
  <form action="insertion_cert.php" method="post">
    <p>
        <label for="cert">certifications </label>
        <input type="text" id="cert" name="cert"/>
    </p>
    <p> <input type="submit" class="btn btn-primary"></button>

    </form>
  </body>