
<?php include('inc/header.inc.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1> Bienvenue dans l'administration des sections</h1>
<ul>
<li> 
    <a href="pres/formulaire_ajout_pres.php" class="btn btn-default"> ajouter des informations personnelles</a>
    <br>
    <br>
    <a href="pres/lister_pers.php" class="btn btn-default"> Liste des informations personnelles</a>
    <br>
    <br>
    <br>
    <br>
    <a href="formulaire_ajout_experience.php" class="btn btn-default"> ajouter une experience</a>
    <br>
    <br>
    <a href="lister.php" class="btn btn-default"> Liste des experiences</a>
    <br>
    <br>
    <br>
    <br>
    <a href="education/formulaire_ajout_education.php" class="btn btn-default" >Ajoutez une Education</a>
   <br>
   <br>
   <a href="education/lister_education.php" class="btn btn-default"> Liste des educations</a>
   <br>
   <br>
   <br>
   <br>
   <a href="interet/formulaire_ajout_interet.php" class="btn btn-default" >Ajoutez des centres d'interets</a>
   <br>
   <br>
   <a href="interet/lister_interet.php" class="btn btn-default"> Liste des centres d'interets</a>
   <br>
   <br>
   <br>
   <br>
   <a href="certification/formulaire_ajout_cert.php" class="btn btn-default" >Ajoutez des certifications</a>
   <br>
   <br>
   <a href="certification/lister_cert.php" class="btn btn-default"> Liste des certifications</a>
   <br>
   <br>
   <br>
   <br>
    <a href="index.php" class="btn btn-default " > retour a votre cv</a>
</body>  
</html>